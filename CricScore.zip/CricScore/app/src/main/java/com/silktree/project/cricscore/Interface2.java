/*
    NAME: Interface2.java
    AUTHOR: Joel Julian
    DATE: 08-JUL-2017
    DESCRIPTION: This file will hold all the functions related to second interface
* */
package com.silktree.project.cricscore;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class Interface2 extends AppCompatActivity {

    //member variables
    private String battingTeamName;
    private String bowlingTeamName;
    private int totalNoOfPlayers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interface2);

        //Getting the intent passed from interface 1
        Intent intent = getIntent();
        //Extracting all the information sent from interface 1
        battingTeamName = intent.getStringExtra("battingTeamName");
        bowlingTeamName = intent.getStringExtra("bowlingTeamName");
        totalNoOfPlayers = intent.getIntExtra("totalNoOfPlayers", 1);

        //Displaying information
        Toast.makeText(this, battingTeamName + " " + bowlingTeamName + " " + totalNoOfPlayers, Toast.LENGTH_LONG).show();
    }
}
